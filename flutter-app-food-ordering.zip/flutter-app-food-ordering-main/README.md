# Food Ordering App - Flutter

- Preview video: https://youtu.be/h1Cw7IoJByU
- [My Twitter](https://twitter.com/sangvaleap)

- [My Patreon](https://www.patreon.com/sangvaleap)
- [My Linkedin](https://www.linkedin.com/in/sangvaleap-vanny-353b25aa/)
- [My Upwork](https://www.upwork.com/freelancers/~01482fe63544bbcb48)

- My Email: sangvaleap.vanny@gmail.com
- UI/UX source: https://www.behance.net/gallery/131805657/Food-Delivery-UI-Kit

=> To access complete source code, please join [My Patreon](https://www.patreon.com/sangvaleap)

<img width="600" alt="Screen Shot 2022-01-01 at 1 08 04 PM" src="https://user-images.githubusercontent.com/86506519/147845117-f8533d4d-faec-477e-be2e-dfb3c3c573eb.png">
<img width="600" alt="food2" src="https://user-images.githubusercontent.com/86506519/147852827-400269be-0c87-4a51-bc76-c4bec133016a.png">

<img width="599" alt="Screen Shot 2022-01-01 at 1 08 57 PM" src="https://user-images.githubusercontent.com/86506519/147845124-628e74ca-8a21-425c-9798-fa8bded17922.png">
<img width="600" alt="Screen Shot 2022-01-01 at 1 09 44 PM" src="https://user-images.githubusercontent.com/86506519/147845125-48fd4834-7697-4b49-8952-87239df32f76.png">
<img width="600" alt="food7" src="https://user-images.githubusercontent.com/86506519/147854540-0900506a-aa41-4e3f-a946-5c8f5d44e94f.png">
<img width="601" alt="Screen Shot 2022-01-01 at 1 10 10 PM" src="https://user-images.githubusercontent.com/86506519/147845126-cbd3d2a3-53c0-4a20-8f03-4e5f5b8bfb16.png">
<img width="600" alt="Screen Shot 2022-01-01 at 1 10 27 PM" src="https://user-images.githubusercontent.com/86506519/147845127-26b17dd5-0761-46f6-920c-3fac48cac686.png">
