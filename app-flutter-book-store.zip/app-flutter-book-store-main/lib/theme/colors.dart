import 'package:flutter/material.dart';

const primary = Colors.black;
const secondary = Colors.white;
const mainColor = Color(0xFF000000);
const appBgColor = Color(0xFFF5F5F5);
const bottomBarColor = Colors.black;
const shadowColor = Colors.black87;