# Fashion Shop App - Flutter

- Preview video: https://youtu.be/TSg8QXCYfhY
- Support my work: https://www.patreon.com/sangvaleap

- [My Patreon](https://www.patreon.com/sangvaleap)
- [My Linkedin](https://www.linkedin.com/in/sangvaleap-vanny-353b25aa/)
- [My Upwork](https://www.upwork.com/freelancers/~01482fe63544bbcb48)
- [My Twitter](https://twitter.com/sangvaleap)

- My Email: sangvaleap.vanny@gmail.com

=> To access complete source code, please join [My Patreon](https://www.patreon.com/sangvaleap)


<img width="600" alt="fs1" src="https://user-images.githubusercontent.com/86506519/153209520-a51f8aa3-fb00-464b-890f-1608e014e663.png">
<img width="600" alt="fs2" src="https://user-images.githubusercontent.com/86506519/153209547-3767877a-5dd6-4fa9-8457-ebd4d82354ce.png">
<img width="600" alt="fs3" src="https://user-images.githubusercontent.com/86506519/153209554-37f3355c-c411-4ed7-a1df-623e12f5d5ca.png">
<img width="598" alt="fs4" src="https://user-images.githubusercontent.com/86506519/153209563-c3f40ac0-bb8d-4cbd-956f-eb4fa330a0b1.png">
<img width="600" alt="fs5" src="https://user-images.githubusercontent.com/86506519/153712067-26f67c2a-1cad-4183-b7d7-74645e63fd31.png">
<img width="600" alt="fs6" src="https://user-images.githubusercontent.com/86506519/153209579-8b387c70-37ff-41e0-afd8-4ca24e0410b7.png">
