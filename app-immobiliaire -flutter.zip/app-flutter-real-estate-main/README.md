# Real Estate App - Flutter

- Preview video: https://youtu.be/11u0KeymAAs
- [My Twitter](https://twitter.com/sangvaleap)

- [My Patreon](https://www.patreon.com/sangvaleap)
- [My Linkedin](https://www.linkedin.com/in/sangvaleap-vanny-353b25aa/)
- [My Upwork](https://www.upwork.com/freelancers/~01482fe63544bbcb48)

- My Email: sangvaleap.vanny@gmail.com

=> To access complete source code, please join [My Patreon](https://www.patreon.com/sangvaleap)

<img width="600" alt="Screen Shot 2022-01-05 at 6 43 05 PM" src="https://user-images.githubusercontent.com/86506519/148213269-45f3ba01-d059-43f2-85c4-1d31543f06f5.png">
<img width="600" alt="Screen Shot 2022-01-05 at 6 43 24 PM" src="https://user-images.githubusercontent.com/86506519/148213286-e2f3c5f4-581f-4011-afb5-4e702f5724d7.png">
<img width="600" alt="Screen Shot 2022-01-05 at 6 43 45 PM" src="https://user-images.githubusercontent.com/86506519/148213292-078c3fe6-ad7d-4e04-adfe-23b1656dfa14.png">
<img width="599" alt="Screen Shot 2022-01-05 at 6 44 48 PM" src="https://user-images.githubusercontent.com/86506519/148213300-b765d20b-7bb2-49ea-b290-b923f660e9c7.png">
<img width="600" alt="Screen Shot 2022-01-05 at 6 45 16 PM" src="https://user-images.githubusercontent.com/86506519/148213303-7f83c8b7-7736-4e3e-91c7-377b93fd79c5.png">
<img width="601" alt="Screen Shot 2022-01-05 at 6 44 06 PM" src="https://user-images.githubusercontent.com/86506519/148213295-77f7f1cf-bfd0-49c2-a7a1-65e204964c20.png">
<img width="600" alt="Screen Shot 2022-01-05 at 6 44 22 PM" src="https://user-images.githubusercontent.com/86506519/148213298-090fc88d-7e10-4ee0-ae1b-87e06bcf7f35.png">
