package com.example.real_estate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
