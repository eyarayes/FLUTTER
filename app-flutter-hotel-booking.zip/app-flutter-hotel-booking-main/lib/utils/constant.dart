const int ANIMATED_BODY_MS = 500;
