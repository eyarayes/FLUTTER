package com.sangvaleap.hotel_booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
